import * as React from "react";
import {observer} from "mobx-react";

export interface BillingProps {
  form: any;
}

@observer
class Billing extends React.Component<BillingProps> {
  render() {
    return (
      <div>Billing Page</div>
    )
  }
}

export default Billing;