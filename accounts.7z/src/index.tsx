import * as React from "react";
import { render } from "react-dom";
import { App } from "./containers/app";

render(<App/> , document.getElementById("root"));
