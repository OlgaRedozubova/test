import {action, observable} from "mobx";
//
class ErrorsModel {
    @observable isError: boolean = false;
    @observable errMessage: string = '';

    @action clearError = () => {
        console.log('clearError');
        this.isError = false;
        this.errMessage = '';
    };

    @action errorMessage = (err) => {
        if (err.response.data && err.response.data.errors) {
            const error = err.response.data.errors[0];
            if (error) {
                this.isError = true;
                this.errMessage = error.message;
            } else {
                console.log('ERROR login =>', err.response);
            }
        } else {
            console.log('ERROR login =>', err);
        }
    };

    @action checkUnauthorized = (err) => {
        if (err.response && err.response.status === 401) {
            console.log('err.response=>', err.response.status, err.response);
            if (err.response && err.response.data[0] ) {
              const resData = err.response.data[0];
              console.warn(`[${resData.id}]: ${resData.message}`);
            }
            window.location.href = '/login';
        }
    }

}

export const Errors = new ErrorsModel();
