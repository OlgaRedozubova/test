import { Auth } from "./auth";
import { Errors } from "./errors";

export {Auth};
export {Errors};

const stores = {
  Auth,
  Errors
};

export default stores;
