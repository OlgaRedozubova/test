import {
    action, observable, //observable
} from "mobx";
import axios from "axios";
import Cookies from 'js-cookie';
import { Errors } from './';

axios.defaults.headers.common['Content-Type'] = 'application/json';

class AuthModel {
    @observable userName: string = '';
    @observable alertMessage: string = '';
    @observable isLogin: boolean = false;

    @action setUserName = (userEmail: string) => {
      this.isLogin = true;
      this.userName = userEmail;
    };

    @action logIn = (userName: string, password:string) => {
        Errors.clearError();
        this.userName = userName;
        this.isLogin = false;
        console.log('this.userName=>', this.userName);
        axios.post('/v1/user/login', {email: userName, password: password})
            .then((response) => {
                const data = response.data;
                if (data.message === 'user_logged_in' && data.token) {
                    Cookies.set('token', `Bearer ${data.token}`);
                   //history.lo push('/login');
                    this.isLogin = true;
                   // window.location.href = '/editor';
                } else {
                    this.userName =  '';
                    console.log('WRONG!!! => data', data);
                }
            })
            .catch(err=> {
                this.userName =  '';
                Errors.errorMessage(err);
            });
    };

    @action singIn = (userName: string, password:string) => {
        Errors.clearError();
        this.userName =  '';
        this.alertMessage = '';

        const config = {
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include'
        };
        axios.post('/v1/user/register', {email: userName, password: password, improve_mathpix: false}, config)
        .then((response) => {
            if (response.data && response.data.message === 'sent_verification_email') {
                this.alertMessage = 'Verification email has been sent to your email!';
            }
        })
        .catch(err => {
            Errors.errorMessage(err);
        });
    };
    @action singOut = () => {
        Errors.clearError();
        this.userName =  '';
        this.alertMessage = '';

        const token = Cookies.get('token');
        const config = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': token
            },
            credentials: 'include'
        };
        axios.post('/v1/user/logout', {}, config)
            .then((response) => {
                if (response.data && response.data.message === 'user_logged_out') {
                    Cookies.remove('token');
                    window.location.href = '/';
                } else {
                    console.log('response=>', response);
                }
            })
            .catch(err=> {
                Errors.errorMessage(err);
            });
    };
}

export const Auth = new AuthModel();
