import * as React from 'react';
import { Switch, Route, BrowserRouter, Redirect } from 'react-router-dom';
import Cookies from 'js-cookie';

import Login from "../components/login";
import Billing from "../components/billing";

import {setAxiosConfig} from "../services/axios";
import {observer} from "mobx-react";
import {Auth} from "../model";

@observer
export class App extends React.Component {
  constructor(props) {
    super(props);
    setAxiosConfig();
  }

  render() {
    const isLogin = Auth.isLogin;
    const token = Cookies.get('token');
    return (
      <>
        <BrowserRouter>
          <>
              <Switch>
                <Route exact path="/" render={() => ( (token && token !== '') ? ( <Redirect to="/billing"/> ) : ( <Redirect to="/login"/> ) )} />
                <Route path="/billing" component={Billing}  />
                <Route exact path="/login" render={() => ( isLogin ? ( <Redirect to="/billing"/> ) : ( <Login/> ) )}/>
              </Switch>
          </>
        </BrowserRouter>
      </>
    );
  }
}
