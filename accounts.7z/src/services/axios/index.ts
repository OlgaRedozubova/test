import axios from 'axios';

export const setAxiosConfig = () => {
    axios.defaults.baseURL = process.env.REACT_APP_GATEWAY_URL || 'http://localhost:8080';
};
