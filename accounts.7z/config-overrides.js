const tsImportPluginFactory = require('ts-import-plugin');
const { getLoader } = require("react-app-rewired");
const rewireLess = require('react-app-rewire-less');

module.exports = function override(config, env) {
  //do stuff with the webpack config...

  const tsLoader = getLoader(
    config.module.rules,
    rule =>
      rule.loader &&
      typeof rule.loader === 'string' &&
      rule.loader.includes('ts-loader')
  );

  tsLoader.options = {
    getCustomTransformers: () => ({
      before: [ tsImportPluginFactory({
        libraryDirectory: 'es',
        libraryName: 'antd',
        style: true,
      }) ]
    })
  };

  config = rewireLess.withLoaderOptions({
    javascriptEnabled: true,
    modifyVars: {
      "@primary-color": "#0B93ff",
      "@link-color": "#0B93ff",
      "@text-color": "#1E2029",
      "@menu-item-color":"#7D829C",
      "@menu-highlight-color": "#1E2029",
      "@menu-item-active-bg": "#F2F3F6",
      "@menu-item-active-border-width": "1px",
      "@item-active-bg":"#F2F3F6",
      "@item-hover-bg": "#F2F3F6"
    },
  })(config, env);

  return config;
};